﻿using System;
using System.Linq;
using ConsoleApp1;

namespace LinqToSqlLesson1
{
    internal class Program
    {
        private const string ConnectionString =
            @"Data Source=(localdb)\MSSQLLocalDB;" +
            "Initial Catalog=SchoolLinqDb;" +
            "Integrated Security=True";
        public static void Main()

        {
            using (SculDataContext db = new SculDataContext(ConnectionString))
            {
                Console.WriteLine("=== ПРАКТИКА 1 ===");

                var adults = db.Students
                    .Where(s => s.Age > 18)
                    .ToList();

                Console.WriteLine("\nСтуденты старше 18 лет:");
                foreach (var s in adults)
                {
                    Console.WriteLine(
                        $"{s.FirstName} {s.LastName}, возраст: {s.Age}");
                }

                var sorted = db.Students
                    .OrderBy(s => s.LastName)
                    .ToList();

                Console.WriteLine("\nСтуденты по фамилии:");
                foreach (var s in sorted)
                {
                    Console.WriteLine(
                        $"{s.FirstName} {s.LastName}");
                }

                var byName = db.Students
                    .Where(s => s.FirstName.StartsWith("А"))
                    .ToList();

                Console.WriteLine("\nИмена на букву A:");
                foreach (var s in byName)
                {
                    Console.WriteLine(
                        $"{s.FirstName} {s.LastName}");
                }

                var studentInfo = db.Students
                    .Select(s => new
                    {
                        s.FirstName,
                        s.LastName,
                        s.Age
                    })
                    .ToList();

                Console.WriteLine("\nИмя, фамилия и возраст:");
                foreach (var s in studentInfo)
                {
                    Console.WriteLine(
                        $"{s.FirstName} {s.LastName}, возраст: {s.Age}");
                }


                Console.WriteLine("\n=== ПРАКТИКА 2 ===");
                int count = db.Students.Count();

                Console.WriteLine($"\nКоличество студентов: {count}");

                if (count > 0)
                {

                    double averageAge = db.Students
                        .Average(s => (double)s.Age);
                    Console.WriteLine(
                        $"Средний возраст: {averageAge:F2}");

                    var youngest = db.Students
                        .OrderBy(s => s.Age)
                        .FirstOrDefault();

                    var oldest = db.Students
                        .OrderByDescending(s => s.Age)
                        .FirstOrDefault();

                    Console.WriteLine(
                        $"\nСамый младший: {youngest.FirstName} " +
                        $"{youngest.LastName}, возраст: {youngest.Age}");

                    Console.WriteLine(
                        $"Самый старший: {oldest.FirstName} " +
                        $"{oldest.LastName}, возраст: {oldest.Age}");

                    var students18To21 = db.Students
                        .Where(s => s.Age >= 18 && s.Age <= 21)
                        .ToList();

                    Console.WriteLine("\nСтуденты в возрасте от 18 до 21 года:");

                    foreach (var s in students18To21)
                    {
                        Console.WriteLine(
                            $"{s.FirstName} {s.LastName}, возраст: {s.Age}");
                    }

                    var firstThree = db.Students
                        .OrderBy(s => s.LastName)
                        .Take(3)
                        .ToList();

                    Console.WriteLine("\nПервые три студента по фамилии:");

                    foreach (var s in firstThree)
                    {
                        Console.WriteLine(
                            $"{s.FirstName} {s.LastName}");
                    }
                }
                else
                {
                    Console.WriteLine("В таблице Students нет студентов.");
                }
            }

            Console.WriteLine("\nНажмите любую клавишу для выхода...");
            Console.ReadKey();
        }
    }
}